def hello_world(name="World"):
    '''A simple test function that returns a greeting message.'''
    return f"Hello, {name}! This package works!"


def add_numbers(a, b):
    '''A simple function that adds two numbers.'''
    return a + b
