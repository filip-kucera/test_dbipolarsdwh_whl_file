import polars as pl
from polars import col, lit
import notebookutils as nu
from datetime import datetime, timezone
from deltalake import DeltaTable
import os

def add_timestamp_column(df, column_name, timestamp = None):
    timestamp = timestamp or datetime.now(timezone.utc)
    return df.with_columns(lit(timestamp).cast(pl.Datetime(time_unit="us",time_zone="UTC")).alias(column_name))

def collect_if_lazy(df):
    if isinstance(df, pl.LazyFrame):
        df = df.collect()
    return df

def merge_delta(df, target_path, merge_predicate):    
    df = collect_if_lazy(df)
    #target_path = lakehouse.abfss_table_path(dataset_name)
    
    if not nu.fs.exists(target_path):
        df.write_delta(
            target_path,
            mode = "overwrite",
            delta_write_options = {"schema_mode": "overwrite"}
        )
        return 
    
    merger = df.write_delta(
        target_path,
        mode = "merge",
        delta_write_options = {"schema_mode": "overwrite"},
        delta_merge_options = {
            "source_alias": "s", "target_alias": "t",
            "predicate": merge_predicate,
        }
    )
    merger = merger.when_matched_update_all()
    merger = merger.when_not_matched_insert_all()
    merger.execute()
    
def overwrite_delta(df, target_path, replace_predicate = None):  
    df = collect_if_lazy(df)
    mode = "overwrite"
    #target_path = lakehouse.abfss_table_path(dataset_name)
    
    delta_write_options = {"schema_mode": "overwrite"}
    if replace_predicate and nu.fs.exists(target_path):
        dt = DeltaTable(target_path)
        dt.delete(replace_predicate)
        mode = "append"
    
    df.write_delta(
        target_path,
        mode = mode,
        delta_write_options = delta_write_options
    )
    
def append_delta(df, target_path):    
    df = collect_if_lazy(df)
    #target_path = lakehouse.abfss_table_path(dataset_name)
    
    delta_write_options = {"schema_mode": "overwrite"}
    
    df.write_delta(
        target_path,
        mode = "append",
        delta_write_options = delta_write_options
    )
    
def compose_file_path(lakehouse, dataset_name, partition = None, extension = "parquet"):
        load_timestamp = datetime.now(timezone.utc)
        file_name = load_timestamp.strftime(f"%Y%m%d%H%M%S.{extension}")
        
        relative_path = f"Files/Data/{dataset_name}/{file_name}"
        if partition:
            relative_path = f"Files/Data/{dataset_name}/{partition}/{file_name}"
        
        full_path = lakehouse.local_file_path(relative_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        return full_path    

def save_dataframe_to_parquet(df, lakehouse, dataset_name, partition = None):
    file_path = compose_file_path(lakehouse, dataset_name, partition, "parquet")
    df.write_parquet(file_path)

def save_content_to_file(file_content, lakehouse, dataset_name, partition = None, extension = "parquet"):
    file_path = compose_file_path(lakehouse, dataset_name, partition, extension)
    with open(file_path, "wb") as file:
        file.write(file_content)
    
def scan_all_tables(lakehouses):    
    table_paths = []
    for lakehouse in lakehouses:
        table_paths.extend(lakehouse.get_all_tables())
    
    dfs = []

    for table_path in table_paths:
        df = pl.scan_delta(table_path)
        dataset_name = table_path.split("/Tables/")[1]
        [schema, table] = dataset_name.split("/")

        columns = df.collect_schema().names()
        df = df.select(
            pl.col("L0_timestamp").max() if "L0_timestamp" in columns else pl.lit(None).cast(pl.Datetime(time_unit = "us", time_zone = "UTC")).alias("L0_timestamp"),
            pl.col("L1_timestamp").max() if "L1_timestamp" in columns else pl.lit(None).cast(pl.Datetime(time_unit = "us", time_zone = "UTC")).alias("L1_timestamp"),
            pl.col("L2_timestamp").max() if "L2_timestamp" in columns else pl.lit(None).cast(pl.Datetime(time_unit = "us", time_zone = "UTC")).alias("L2_timestamp"),
            pl.lit(table).alias("Table"),
            pl.lit(schema).alias("Schema"),
        )

        dfs.append(df)

    return pl.concat(dfs, rechunk = True).collect(streaming = True)

def pl_cast_sharepoint_date(col):
    return (col + pl.duration(hours = 3)).cast(pl.Date)

def load_table_to_dataframe(lakehouse, dataset_name):
    df = pl.scan_delta(lakehouse.abfss_table_path(dataset_name))
    return df

def exit_notebook(start_timestamp, message):
    end_timestamp = datetime.now(timezone.utc)
    message = f"{start_timestamp}; {end_timestamp}; {message}"
    nu.notebook.exit(message)
    
    
def normalize_object(obj):
    if isinstance(obj, dict):
        return {k: normalize_object(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [normalize_object(i) for i in obj]
    elif isinstance(obj, int) or isinstance(obj, float):
        return float(obj)  # normalize all numeric values to float
    return obj