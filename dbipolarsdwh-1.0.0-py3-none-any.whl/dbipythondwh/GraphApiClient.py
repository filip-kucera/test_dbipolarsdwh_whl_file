from datetime import datetime, timedelta
from requests import request

class GraphApiClient:
    def __init__(self, client_id, client_secret, tenant_id):
        self.client_id = client_id
        self.client_secret = client_secret
        self.tenant_id = tenant_id

        self.token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
        self.graph_base_url = "https://graph.microsoft.com"

        self.access_token = None
        self.access_token_expiration = None
        
        self.refresh_access_token()
    
    def __compose_url(self, url, api_version, select = None, expand = None):
        if url.startswith(self.graph_base_url):
            return url

        output = f"{self.graph_base_url}/{api_version}/{url}?"

        if select:
            output = output + f"&$select={select}"
        if expand:
            output = output + f"&$expand={expand}"
        
        return output
    
    def refresh_access_token(self):
        if self.access_token and self.access_token_expiration > datetime.utcnow():
            return
        
        body = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "scope": "https://graph.microsoft.com/.default",
            "grant_type": "client_credentials"
        }
        request_timestamp = datetime.utcnow()
        
        response = request("POST", self.token_url, data=body)
        response = self.__handle_response(response)
        access_token = response["body"].get("access_token")
        expires_in = response["body"].get("expires_in")
        
        self.access_token = access_token
        self.access_token_expiration = request_timestamp + timedelta(seconds=expires_in - 30)
    
    def authorized_request(self, method, url, select = None, expand = None, body = None, api_version = "v1.0"):
        self.refresh_access_token()
        
        headers = {"Authorization": f"Bearer {self.access_token}"}
        url = self.__compose_url(url, api_version, select, expand)
        
        response = request(method, url, headers=headers, json=body)
        response = self.__handle_response(response)

        return response

    def authorized_get_paginated(self, url, select = None, expand = None, api_version = "v1.0"):
        results = []

        while url:
            response = self.authorized_request(
                "GET", 
                url, 
                select = select, 
                expand = expand, 
                api_version = api_version
            )
            data = response["body"]

            results.extend(data.get("value", []))
            url = data.get("@odata.nextLink")
        
        return results
    
    def __handle_response(self, response):
        status_code = response.status_code or response.status
        content_type = response.headers.get("Content-Type")

        if status_code >= 400:
            raise Exception(f"HTTP error with status code: {status_code}; content: '{response.text}'")
        
        response_body = None
        if "json" in content_type:
            try:
                response_body = response.json()
            except:
                response_body = response.content
        else:
            response_body = response.content

        return {
            "status_code": status_code,
            "body": response_body,
            "headers": response.headers
        }
    
    # --------------- ASYNC METHODS ---------------
    
    async def authorized_request_async(self, aio_session, aio_semaphore, method, url, select = None, expand = None, body = None, api_version = "v1.0"):
        headers = {"Authorization": f"Bearer {self.access_token}"}
        url = self.__compose_url(url, api_version, select, expand)

        async with aio_semaphore:
            async with aio_session.request(method, url, headers=headers, json=body) as response:
                response = await self.__handle_response_async(response)
                return response
    
    async def authorized_get_paginated_async(self, aio_session, aio_semaphore, url, select = None, expand = None, api_version = "v1.0"):
        results = []

        while url:
            response = await self.authorized_request_async(
                aio_session, 
                aio_semaphore, 
                "GET", 
                url, 
                select = select, 
                expand = expand, 
                api_version = api_version
            )
            data = response["body"]

            results.extend(data.get("value", []))
            url = data.get("@odata.nextLink")
        
        return results

    async def __handle_response_async(self, response):
        status_code = response.status
        content_type = response.headers.get("Content-Type")

        if status_code >= 400:
            raise Exception(f"HTTP error with status code: {status_code}; content: '{response.text}'")
        
        response_body = None
        if "json" in content_type:
            response_body = await response.json()
        else:
            response_body = response.content

        return {
            "status_code": status_code,
            "body": response_body,
            "headers": response.headers
        }