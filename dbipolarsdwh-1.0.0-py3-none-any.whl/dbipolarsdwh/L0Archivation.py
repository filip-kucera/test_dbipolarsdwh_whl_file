import datetime
import notebookutils as nu
import json

# TODO: could be optimized by using glob instead of recursive calls

class L0Archivation:
    def __init__(self, l0_lakehouse):
        self.__l0_lakehouse = l0_lakehouse
        self.__load_definition_folder = self.__l0_lakehouse.abfss_file_path("Files/Metadata/Load_definitions")
        
    # get definition from all files in definition folder
    def __get_load_definitions(self, load_filters):       
        if not nu.fs.exists(self.__load_definition_folder):
            raise Exception(f"Path does not exist: {self.__load_definition_folder}")
        
        definition_files = nu.fs.ls(self.__load_definition_folder)
        all_load_definitions = []
        
        for definition_file in definition_files:
            file_content = nu.fs.head(definition_file.path, max_bytes = 1024 * 1000)
            load_definitions = json.loads(file_content)
            all_load_definitions += load_definitions

        # filter load definitions
        filtered_load_definitions = all_load_definitions
        
        filtered_load_definitions = [
            d for d in filtered_load_definitions 
            if 
                d["job_name"].split("/", 1)[-1].startswith("L0")  # filter by tier
                and (
                    (not load_filters) # no filters provided
                    or (d["job_name"] in load_filters)  # filter by job_name
                    or (bool(set(d.get("tags", "").split(" ")) & set(load_filters))) # filter by tags
                )
        ]

        return filtered_load_definitions
        max_modified_timestamp = None
        max_modified_timestamp_index = None
        max_modified_timestamp_file = None

        for file_index, file in enumerate(files):
            if (not max_modified_timestamp) or (file["timestamp"] > max_modified_timestamp):
                max_modified_timestamp = file["timestamp"]
                max_modified_timestamp_index = file_index
                max_modified_timestamp_file = file
            
        return (max_modified_timestamp_file, max_modified_timestamp_index)
    
    # split items into files and directories
    def __get_split_items_by_type(self, items):
        files = []
        directories = []
        
        for item in items:
            # is directory
            if (item.size == 0) and ("." not in item.name):
                directories.append(item)
            else:
                files.append({
                    "name": item.name,
                    "path": item.path,
                    "timestamp": self.__get_file_timestamp(item.name)
                })

        return (files, directories)
                
    # apply archive policy: keep last N snapshots
    def __apply_keep_last_n(self, job_name, subdirectory = "", n = 1):
        current_path = self.__l0_lakehouse.abfss_file_path(
            f"Files/L0_snapshots/{job_name}"
        )
        current_path = current_path + subdirectory
        
        if not nu.fs.exists(current_path):
           return
        
        current_directory_items = nu.fs.ls(current_path)

        (files, directories) = self.__get_split_items_by_type(current_directory_items)
        removed_count = 0
        failed_count = 0
    
        if files:
            # sort files by timestamp desc and keep the first n items
            files_sorted = sorted(files, key = lambda f: f["timestamp"], reverse = True)
            to_remove = files_sorted[n:]
            
            for file in to_remove:
                try:
                    nu.fs.rm(file["path"], True)
                    removed_count = removed_count + 1
                except Exception as e:
                    failed_count = failed_count + 1
                    print(e)

        if removed_count > 0 or failed_count > 0:
            print(f"Removed files: {removed_count}, failed removes: {failed_count} in {job_name}{subdirectory}")
        
        for directory in directories:
            # propagate keep_last_count into recursive calls
            self.__apply_keep_last_n(job_name, subdirectory = f"{subdirectory}/{directory.name}", n = n)     

    # apply archive policies for all datasets in definition file
    def run(self, load_filters = []):
        load_definitions = self.__get_load_definitions(load_filters)
               
        for definition in load_definitions:           
            # keep only last N snapshots for each subdirectory
            if definition["archivation_policy"].startswith("KeepLast"):
                self.__apply_keep_last_n(definition["job_name"], n = self.__get_keep_last_n(definition["archivation_policy"]))
                
    # get timestamp from file name    
    def __get_file_timestamp(self, file_name):
        file_timestamp = int(file_name.split(".")[0])
        return file_timestamp
    
    # extract number after "KeepLast", default to 1 when absent or invalid
    def __get_keep_last_n(self, archivation_policy):
        if archivation_policy.startswith("KeepLast"):
            policy_tail = archivation_policy[len("KeepLast"):]
            try:
                keep_count = int(policy_tail) if policy_tail else 1
            except Exception:
                keep_count = 1
            if keep_count < 1:
                keep_count = 1
            return keep_count
        return None