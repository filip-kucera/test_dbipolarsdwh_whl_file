import notebookutils as nu
import json

def save_definition(name, definition, lakehouse):
    nu.fs.put(
        lakehouse.abfss_file_path(f"Files/Metadata/Load_definitions/{name}.json"),
        json.dumps(definition, indent = 4),
        overwrite = True
    )
    
def get_all_definitions(frame):
    defs_vars = {name.split("_", 1)[1]: value for name, value in frame.items() if name.startswith("defs_")}
    return defs_vars