import notebookutils as nu
import sempy.fabric as fabric 

class Lakehouse:
    def __init__(self, name, workspace_id, lakehouse_id, mounted = False):
        self.__mounted = mounted
        self.__name = name
        
        self.workspace_id = workspace_id
        self.lakehouse_id = lakehouse_id
        
        self.__abfss_path = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
        self.__local_path = self.__mount_lakehouse() if mounted else None
        
        self.__fabric_client = fabric.FabricRestClient()

    def __mount_lakehouse(self):
        mount_name = f"/{self.__name}"
        try:
            return nu.fs.getMountPath(mount_name)
        except:
            nu.fs.mount(self.__abfss_path, mount_name) 
            return nu.fs.getMountPath(mount_name)

    def local_path(self):    
        if not self.__mounted:
            raise Exception("Lakehouse is not mounted")   
        return self.__local_path

    def abfss_path(self):
        return self.__abfss_path

    def abfss_table_path(self, table_name, schema = None):
        if schema:
            return f"{self.__abfss_path}/Tables/{schema}/{table_name}"
        return f"{self.__abfss_path}/Tables/{table_name}"

    def abfss_file_path(self, file):
        return f"{self.__abfss_path}/{file}"
    
    def local_file_path(self, file):
        if not self.__mounted:
            raise Exception("Lakehouse is not mounted")   
        return f"{self.__local_path}/{file}"
    
    def __get_sql_endpoint(self):
        uri = f"/v1/workspaces/{self.workspace_id}/lakehouses/{self.lakehouse_id}"
        sql_endpoint = self.__fabric_client.get(uri).json()["properties"]["sqlEndpointProperties"]["id"]
        return sql_endpoint

    def refresh_sql(self):
        sql_endpoint = self.__get_sql_endpoint()
        payload = {"commands":[{"$type":"MetadataRefreshExternalCommand"}]}
        uri = f"v1.0/myorg/lhdatamarts/{sql_endpoint}"
        
        response = self.__fabric_client.post(uri, json = payload)
        
       
    def get_all_tables(self):
        tables = []

        lakehouse_schemas = [f for f in nu.fs.ls(f"{self.abfss_path()}/Tables") if f.name not in ("dbo")]
        for schema in lakehouse_schemas:
            lakehouse_tables = [f.path for f in nu.fs.ls(schema.path)]
            tables.extend(lakehouse_tables)

        return tables