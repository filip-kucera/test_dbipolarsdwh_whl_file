import notebookutils as nu
from datetime import datetime, timezone
import json
import re

class MetadataLoader:
    def __init__(self, lakehouse, parameters = {}):
        self.__parameters = parameters    
        self.__lakehouse = lakehouse
        self.__load_definition_folder = self.__lakehouse.abfss_file_path("Files/Metadata/Load_definitions") 
        self.__load_definitions = None
    
    # run all notebooks from definiton in parallel   
    def run_load(self, tier, load_frequency, load_filters = [], include_disabled = False, concurrency = 50):
        if self.__load_definitions is None:
            self.__load_definitions = self.__get_load_definitions()   
        
        # filter load definitions
        filtered_load_definitions = self.__load_definitions
        
        filtered_load_definitions = [
            d for d in filtered_load_definitions 
            if 
                d["job_name"].split("/", 1)[-1].startswith(tier)  # filter by tier
                and ((d["status"] == "Enabled") or include_disabled) # by default run only enabled notebooks
                and (d["load_frequency"] in load_frequency)
                and (
                    (not load_filters) # no filters provided
                    or (d["job_name"] in load_filters)  # filter by job_name
                    or (bool(set(d.get("tags", "").split(" ")) & set(load_filters))) # filter by tags
                )
                and ((tier != "L0") or (d["load_tool_type"] == "Notebook")) # for L0 run only nootebooks
        ]
            
        # transform load definitions to DAG activities
        notebook_activities = [*map(lambda d: self.__map_notebook_activity(d, tier), filtered_load_definitions)]

        # run DAG
        results = None
        try:
            results = nu.notebook.runMultiple({
                "activities": notebook_activities,
                "timeoutInSeconds": 1800, # 30 minutes
                "concurrency": concurrency   # had some issues with max concurrency
            })
        except Exception as ex:
            results = ex.result

        formatted_results = self.__get_formatted_results(results)
        return formatted_results
    
    
    # get definition from all files in definition folder
    def __get_load_definitions(self):       
        if not nu.fs.exists(self.__load_definition_folder):
            raise Exception(f"Path does not exist: {self.__load_definition_folder}")
        
        definition_files = nu.fs.ls(self.__load_definition_folder)
        all_load_definitions = []
        
        for definition_file in definition_files:            
            file_content = nu.fs.head(definition_file.path, max_bytes = 1024 * 1000)
            load_definitions = json.loads(file_content)
            all_load_definitions += load_definitions

        return all_load_definitions
        
    def __get_formatted_results(self, results):
        formated_results = []
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')

        for result_name in results:
            result = results[result_name]
            formated_results.append({
                "activity": result_name,
                "status": "Succeeded" if not result["exception"] else "Failed",
                "details": ansi_escape.sub('', str(result['exception'])) if result["exception"] else ""
            })
            
        return formated_results
    
    # map definition structure to DAG
    def __map_notebook_activity(self, load_definition, tier):
        notebook_activity_args = {}
        
        # for L0 loads, pass all parameters as strings
        if tier == "L0":
            for k in load_definition.keys():
                if isinstance(load_definition[k], list) or isinstance(load_definition[k], dict):
                    notebook_activity_args[k] = json.dumps(load_definition[k])
                else:
                    notebook_activity_args[k] = str(load_definition[k])
        
        # merge with config parameters
        notebook_activity_args = notebook_activity_args | self.__parameters 
        path = load_definition["load_tool_name"] if tier == "L0" else load_definition["job_name"].split("/",1)[-1]
        
        return {
            "name": load_definition["job_name"],
            "path": path,
            "args": notebook_activity_args,
            "dependencies": load_definition.get("dependencies", []),
            "timeoutPerCellInSeconds": 900
        }
    
