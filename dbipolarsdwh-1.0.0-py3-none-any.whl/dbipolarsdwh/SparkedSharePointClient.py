from requests import request
import polars as pl
from polars import col
import os
import uuid

# helper structure to compose SharePoint API queries, PySpark schema and types, PySpark aliases
class SparkedSharePointSchema:
    # all supported SharePoint data types
    __ALLOWED_TYPES = [
        "text",
        "boolean",
        "integer",
        "float",
        "decimal",
        "datetime",
        "date",
        "choice",
        "person",
        "lookup",
        "url",
        "multi_lookup",
        "multi_person",
        "multi_choice",
        "versions"
    ]

    # all supported SparkedSharePoint primitive data types
    __PRIMITIVE_TYPES = [
        "text",
        "boolean",
        "integer",
        "float",
        "decimal",
        "datetime",
        "date",
        "choice"
    ]

    __VERSIONED_TYPES = [
        "text",
        "boolean",
        "integer",
        "float",
        "decimal",
        "datetime",
        "date",
        "choice",
        "person",
        "lookup"
    ]

    # data type mapping between SparkedSharePoint and PySpark
    __SHAREPOINT_TO_SPARK_TYPES_MAP = {
        "text": pl.String,
        "boolean": pl.Boolean,
        "integer": pl.Int32,
        "float": pl.Float64,
        "decimal": pl.Float64,
        # must be parsed using cast()
        "datetime": pl.String,
        # must be parsed using cast()
        "date": pl.String,
        "choice": pl.String
    }
    
    def __init__(self, schema):
        # SparkedSharePoint schema
        self.__schema = schema

        # API select query string
        self.__select_query = ""
        # API expand query string
        self.__expand_query = ""
        
        # self.__spark_schema = None
        # Spark selections, aliases and casts to be applied
        self.__spark_df_selections = []
        
        self.__versioned = None

        # control lazy generation
        self.__generated = False

    # lazy check if schema contains version type
    def is_versioned(self):
        if self.__versioned is None:
            self.__versioned = False
            for col in self.__schema:
                if col["type"] == "versions":
                    self.__versioned = True
                    break

        return self.__versioned

    # validate SparkedSharePoint column
    def __validate_column(self, col):
        if not col.get("srcName"):
            raise Exception("Column source name is missing")
        if not (col.get("type") in self.__ALLOWED_TYPES):
            raise Exception(f"Invalid type for column {col['srcName']}")
        if col.get("dstName") == "":
            raise Exception(f"Destination name is empty for column {col['srcName']}")

    # validate field in SparkedSharePoint complex column
    def __validate_field(self, field):
        if not field.get("srcName"):
            raise Exception("Field source name is missing")
        if not (field.get("type") in self.__PRIMITIVE_TYPES):
            raise Exception(f"Invalid type for field {col['srcName']}/{field['srcName']}")
        if field.get("dstName") == "":
            raise Exception(f"Destination name is missing for field {col['srcName']}/{field['srcName']}")

    def __validate_versioned_field(self, field):
        if not field.get("srcName"):
            raise Exception("Field source name is missing")
        if not (field.get("type") in self.__VERSIONED_TYPES):
            raise Exception(f"Invalid type for field {col['srcName']}/{field['srcName']}")
        if field.get("dstName") == "":
            raise Exception(f"Destination name is missing for field {col['srcName']}/{field['srcName']}")

    # get Spark selection (+ alias, cast) for SparkedSharePoint primitive type
    def __get_primitive_spark_selection(self, src_col_name, src_field_name, dst_name, sparked_sharepoint_type):

        output = col(src_col_name)

        if src_field_name:
            output = output.struct.field(src_field_name)

        if sparked_sharepoint_type == "datetime":
            output = output.str.to_datetime(time_unit= "us", time_zone = "UTC")
        elif sparked_sharepoint_type == "date":
            output = output.str.to_date()

        output = output.alias(dst_name or src_col_name)
        return output

    # lazy output generation
    def __generate(self):
        # API selects
        api_select_array = []
        # API expands
        api_expand_array = []
        
        # Spark schema         
        spark_schema_columns = {}
        # Spark selects (+ alias, cast)
        spark_df_selections = []
    
        # versioned schema cannot contain other columns
        if (self.is_versioned()) and (len(self.__schema) > 1):
            raise Exception("Schema with versions cannot contain other columns")

        for column in self.__schema:
            self.__validate_column(column)

            # primitive types
            if column["type"] in self.__PRIMITIVE_TYPES:
                api_select_array.append(column["srcName"])
                
                spark_schema_columns[column["srcName"]] =  self.__SHAREPOINT_TO_SPARK_TYPES_MAP[column["type"]]
                spark_df_selections.append(self.__get_primitive_spark_selection(column["srcName"], None, column.get("dstName", None), column["type"]))
            
            # url - complex type (Description, Url), always select only Url field
            elif column["type"] == "url":
                api_select_array.append(column["srcName"])
                spark_schema_columns[column["srcName"]] = pl.Struct({
                    "Description": pl.String,
                    "Url": pl.String
                })

                spark_df_selections.append(
                    self.__get_primitive_spark_selection(
                        column["srcName"],
                        "Url",
                        column.get("dstName", None), 
                        "text"
                    )
                )

            # lookup, person - with field expansion
            elif (column["type"] == "lookup") or (column["type"] == "person"):
                # must have at least 1 field
                if len(column["fields"]) < 1:
                    raise Exception(f"No fields were provided for complex column {column['srcName']}")
                
                api_expand_array.append(column["srcName"])
                
                # Spark schema for fields in complex type
                spark_schema_fields = {}
                
                for field in column["fields"]:
                    # allow only primitive fields
                    self.__validate_field(field)

                    api_select_array.append(f"{column['srcName']}/{field['srcName']}")
                    spark_schema_fields[field["srcName"]] = self.__SHAREPOINT_TO_SPARK_TYPES_MAP[field["type"]]

                    spark_df_selections.append(
                        self.__get_primitive_spark_selection(
                            column["srcName"],
                            field["srcName"],
                            field.get("dstName", None), 
                            column["type"]
                        )
                    )

                # compose Spark complex type with fields
                spark_schema_columns[column["srcName"]] = pl.Struct(spark_schema_fields)
            
            # multi choice - array of strings
            elif column["type"] == "multi_choice":
                api_select_array.append(column["srcName"])
                spark_schema_columns[column["srcName"]] = pl.List(pl.String)

                spark_df_selections.append(
                    col(column["srcName"]).alias(column.get("dstName", None) or column["srcName"])
                )
            
            # multi person, multi lookup
            elif (column["type"] == "multi_lookup") or (column["type"] == "multi_person"):
                # can have only 1 field
                if len(column["fields"]) != 1:
                    raise Exception(f"More or less than 1 field was provided for multi complex column {column['srcName']}")
                
                api_expand_array.append(column["srcName"])

                field = column["fields"][0]
                self.__validate_field(field)

                api_select_array.append(f"{column['srcName']}/{field['srcName']}")
                spark_schema_columns[column["srcName"]] = pl.List(pl.Struct({field["srcName"]: self.__SHAREPOINT_TO_SPARK_TYPES_MAP[field["type"]]}))

                spark_df_selections.append(
                    col(column["srcName"]).list.eval(pl.element().struct.field(field["srcName"])).alias(field.get("dstName", None) or column["srcName"])
                )

            # versioned
            elif column["type"] == "versions":
                if len(column["fields"]) < 1:
                    raise Exception(f"No versioned field were provided")

                api_expand_array.append(column["srcName"])

                spark_schema_fields = {}
                for field in column["fields"]:
                    # allow only primitive fields
                    self.__validate_versioned_field(field)

                    # lookup field type
                    if field["type"] == "lookup":
                        if field.get("fields"):
                            raise Exception(f"Versioned lookup field {field['srcName']} cannot contain nested fields") 

                        # needs explicit expand
                        api_expand_array.append(field["srcName"])
                        
                        # versions query need to select both root and versioned fields
                        api_select_array.append(f"{field['srcName']}/ID")
                        api_select_array.append(f"Versions/{field['srcName']}")

                        spark_schema_fields[field["srcName"]] = pl.Struct({"LookupId": pl.Int32, "LookupValue": pl.String})

                        src_name = f"{column['srcName']}.{field['srcName']}"
                        dst_name = field.get("dstName", None)
                        
                        spark_df_selections.append(
                            col(column["srcName"]).struct.field(field["srcName"]).struct.field("LookupId").alias(f"{dst_name or src_name}Id")
                        )

                        spark_df_selections.append(
                            col(column["srcName"]).struct.field(field["srcName"]).struct.field("LookupValue").alias(f"{dst_name or src_name}")
                        )

                    # person field type
                    elif field["type"] == "person":
                        if field.get("fields"):
                            raise Exception(f"Versioned person field {field['srcName']} cannot contain nested fields") 

                        # needs explicit expand
                        api_expand_array.append(field["srcName"])
                        # versions query need to select both root and versioned fields
                        api_select_array.append(f"{field['srcName']}/EMail")
                        api_select_array.append(f"{column['srcName']}/{field['srcName']}")

                        spark_schema_fields[field["srcName"]] = pl.Struct({"Email": pl.String})

                        src_name = f"{column['srcName']}.{field['srcName']}"
                        dst_name = field.get("dstName", None)

                        spark_df_selections.append(
                            col(column["srcName"]).struct.field(field["srcName"]).struct.field("Email").alias(f"{dst_name or src_name}")
                        )

                    # any other versioned field type
                    else:   
                        # versions query need to select both root and versioned fields
                        api_select_array.append(f"{field['srcName']}")
                        api_select_array.append(f"{column['srcName']}/{field['srcName']}")

                        spark_schema_fields[field["srcName"]] = self.__SHAREPOINT_TO_SPARK_TYPES_MAP[field["type"]]
                        
                        spark_df_selections.append(
                            self.__get_primitive_spark_selection(
                                column["srcName"],
                                field["srcName"], 
                                field.get("dstName", None), 
                                field["type"]
                            )
                        )

                # version label
                api_select_array.append(f"{column['srcName']}/VersionLabel")

                spark_schema_fields["VersionLabel"] = pl.String

                spark_df_selections.append(
                    self.__get_primitive_spark_selection(
                        column["srcName"], 
                        "VersionLabel",
                        "Version_label", 
                        "text"
                    )
                )

                api_select_array.append(f"{column['srcName']}/VersionId")
                spark_schema_fields["VersionId"] = pl.Int32

                spark_df_selections.append(
                    self.__get_primitive_spark_selection(
                        column["srcName"], 
                        "VersionId",
                        "Version_ID", 
                        "integer"
                    )
                )

                spark_schema_columns[column["srcName"]] = pl.List(pl.Struct(spark_schema_fields))

            # not implemented types
            else:
                raise Exception(f"Missing implementation for type {column['type']}")

        # save outputs
        self.__spark_schema = spark_schema_columns
        self.__spark_df_selections = spark_df_selections
        self.__select_query = ",".join(api_select_array)
        self.__expand_query = ",".join(api_expand_array)
        self.__generated = True

    def get_spark_df_selections(self):
        if not self.__generated: self.__generate()
        return self.__spark_df_selections

    def get_spark_schema(self):
        if not self.__generated: self.__generate()
        return self.__spark_schema

    def get_api_select_query(self):
        if not self.__generated: self.__generate()
        return self.__select_query

    def get_api_expand_query(self):
        if not self.__generated: self.__generate()
        return self.__expand_query

# public class to consume
class SparkedSharePointClient:
    def __init__(self, sharepoint_domain, tenant_id, client_id, client_secret):
        self.__sharepoint_domain = sharepoint_domain
        self.__tenant_id = tenant_id
        self.__client_id = client_id
        self.__client_secret = client_secret
        
        self.__access_token = ""

    # handle requests.response based on content-type
    def __handle_response(self, response):
        response.raise_for_status()

        body = None
        if ("json" in response.headers["Content-Type"]):
            try:
                body = response.json()
            except:
                body = response.text
        elif ("octet-stream" in response.headers["Content-Type"]):
            body = response.content
        else:
            body = response.text

        return {
            'status_code': response.status_code,
            'headers': response.headers,
            'body': body
        }

    # get SharePoint REST API endpoint URL
    def __get_api_url(self, site_name, relative_url):
        return f"https://{self.__sharepoint_domain}.sharepoint.com/sites/{site_name}/_api" + relative_url

    # get SharePoint REST API endpoint URL for list
    def __get_list_api_url(self, site_name, list_identificator, relative_url = ""):
        if not list_identificator:
            raise Exception("List identificator is empty")
        
        list_identificator_query = ""

        try:
            uuid.UUID(list_identificator)
            list_identificator_query = f"(guid'{list_identificator}')"
        except ValueError:
            list_identificator_query = f"/getByTitle('{list_identificator}')"

        return self.__get_api_url(
            site_name, 
            f"/web/lists{list_identificator_query}{relative_url}"
        )

    # send authorized SharePoint REST API request
    def __send_autorized_request(self, method, url, body = {}):
        if self.__access_token == "": self.__get_access_token()

        headers = {
            "Authorization": self.__access_token,
            "Accept": "application/json; odata=nometadata"
        }

        response = request(method, url, headers=headers, data=body)
        response = self.__handle_response(response)
        return response

    # get new access token
    def __get_access_token(self):
        url = f"https://accounts.accesscontrol.windows.net/{self.__tenant_id}/tokens/OAuth/2"
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        body = {
            "grant_type": "client_credentials",
            "client_id": f"{self.__client_id}@{self.__tenant_id}",
            "client_secret": self.__client_secret,
            "resource": f"00000003-0000-0ff1-ce00-000000000000/{self.__sharepoint_domain}.sharepoint.com@{self.__tenant_id}"
        }
    
        response = request("POST", url, headers=headers, data=body)
        response = self.__handle_response(response)
        
        self.__access_token = "Bearer " + response["body"]["access_token"]

    # get all lists
    def get_lists(self, site_name):
        url = self.__get_api_url(
            site_name,
            f"/web/lists"
        )
        response = self.__send_autorized_request("GET", url)
        return response["body"]["value"]

    # get list details
    def get_list(self, site_name, list_identificator):
        url = self.__get_list_api_url(
            site_name,
            list_identificator
        )
        response = self.__send_autorized_request("GET", url)
        return response["body"]

    # get all items from list
    def get_all_list_items(self, site_name, list_identificator, filter="", select="", expand=""):
        url = self.__get_list_api_url(
            site_name, 
            list_identificator,
            f"/items?$select={select}&$expand={expand}&$top=5000&$filter={filter}"
        )
        
        data_pages = []
        fetch_next = True

        # iterate pages
        while fetch_next:
            response = self.__send_autorized_request("GET", url)
            response_body = response["body"]
            data_pages.append(response_body["value"])
            url = response_body.get("odata.nextLink")
            fetch_next = url != None          

        # flatten pages
        return [item for page in data_pages for item in page]

    # get all items from list as PySpark dataframe using custom schema definition
    def get_all_list_items_dataframe(self, site_name, list_identificator, sparked_schema_definition, filter=""):
        sparked_schema = SparkedSharePointSchema(sparked_schema_definition)
        
        items = self.get_all_list_items(
            site_name,
            list_identificator,
            select = sparked_schema.get_api_select_query(),
            expand = sparked_schema.get_api_expand_query(),
            filter = filter
        )
        
        items_df = pl.DataFrame(items, schema = sparked_schema.get_spark_schema())
        
        if sparked_schema.is_versioned():
            items_df = items_df.explode(col("Versions"))
        
        items_df = items_df.select(sparked_schema.get_spark_df_selections())

        return items_df

    # get list fields
    def get_list_fields(self, site_name, list_identificator):
        url = self.__get_list_api_url(
            site_name,
            list_identificator,
            f"/fields?$select=Title,InternalName,TypeAsString,TypeDisplayName,Required&filter=Hidden eq false"
        )       
        response = self.__send_autorized_request("GET", url)
        return response["body"]["value"]
        
    def get_all_files(self, site_name, relative_path, recursive = False):
        return self.__get_all_files(site_name, f"/sites/{site_name}/{relative_path}", recursive = recursive)

    def __get_all_files(self, site_name, server_relative_path, recursive = False):
        print(f"Fetching files from {server_relative_path}")
        files = []
        
        url = self.__get_api_url(
            site_name,
            f"/web/GetFolderByServerRelativeUrl('{server_relative_path}')?$expand=Folders,Files"
        )
        response = self.__send_autorized_request("GET", url)
        response_body = response["body"]

        files.extend(response_body.get("Files", []))

        if recursive:
            for folder in response_body.get("Folders", []):
                files.extend(
                    self.__get_all_files(site_name, folder["ServerRelativeUrl"], recursive)
                )

        return files

    # get file content as bytes
    def get_file_content(self, site_name, server_relative_path):
        url = self.__get_api_url(
            site_name,
            f"/web/GetFileByServerRelativeUrl('{server_relative_path}')/$value"
        )
        response = self.__send_autorized_request("GET", url)
        return response["body"]