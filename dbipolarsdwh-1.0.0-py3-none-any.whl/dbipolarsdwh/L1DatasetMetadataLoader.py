import notebookutils as nu
import polars as pl
from polars import col, lit
from datetime import datetime

# TODO: could be optimized by using glob instead of recursive calls
class L1DatasetMetadataLoader:
    def __init__(self, l0_lakehouse, l1_lakehouse, src_dataset_name, dst_dataset_name):
        self.__src_full_dataset_name = src_dataset_name
        self.__src_dataset_name = src_dataset_name.split("/", 1)[1]
        
        self.__dst_full_dataset_name = dst_dataset_name
        self.__dst_dataset_name = dst_dataset_name.split("/", 1)[1]
        
        self.__l0_lakehouse = l0_lakehouse
        self.__l1_lakehouse = l1_lakehouse

        self.__last_loaded_timestamp_file = self.__l1_lakehouse.abfss_file_path(f"Files/Metadata/L1_checkpoints/{self.__dst_dataset_name}/{self.__src_dataset_name}.txt")
        
        self.__new_last_load_timestamp = None 
        self.__loaded_files = []

    def load_files(self, only_last = False, only_new = True):
        self.__loaded_files = []        
        self.__loaded_files = self.__get_filtered_files(only_last = only_last, only_new = only_new)
        return self.__loaded_files 

    # load files into dataframe
    def load_files_in_dataframe(self, only_last = False, only_new = True, single_dataframe = True):
        self.load_files(only_last, only_new)
               
        if not self.__loaded_files:
            return None

        file_format = self.__loaded_files[-1]["path"].split(".")[-1]
        if file_format not in ["parquet", "csv", "json"]:
            raise Exception(f"Unsupported file format '{file_format}'")
       
        dfs = []
        for new_file in self.__loaded_files:            
            dfs.append(self.__create_dataframe(new_file, file_format))
            
        if single_dataframe:
            return pl.concat(dfs, rechunk=True)
        
        return dfs

    def get_loaded_files(self):
        return self.__loaded_files

    def get_loaded_files_count(self):
        return len(self.__loaded_files)
    
    # get files based on selected filters
    def __get_filtered_files(self, only_last = False, only_new = True): 
        src_dataset_folder = self.__l0_lakehouse.local_file_path(f"Files/L0_snapshots/{self.__src_full_dataset_name}")      
        files = self.__get_files(src_dataset_folder)
        
        if only_new:
            last_load_timestamp = self.__get_last_load_timestamp()
            files = [
                f for f in files
                if f["timestamp"] > last_load_timestamp
            ]

        if not files:
            return []
               
        (last_modified_file, last_modified_file_index) = self.__get_last_modified_file(files)
        self.__new_last_load_timestamp = last_modified_file["timestamp"]
        
        if only_last:
            return [last_modified_file]

        return files       
    
    # get files recursively
    def __get_files(self, directory, nest = 0):
        if (nest >= 3):
            raise Exception("Directory path nests too deep")

        current_nest_items = nu.fs.ls(directory)
        files = []

        for item in current_nest_items:
            # is directory
            if ("." not in item.name):
                files.extend(self.__get_files(item.path, nest + 1))
            # is not empty
            elif (item.size > 0):  
                files.append({
                    "name": item.name,
                    "path": item.path,
                    "timestamp": self.__get_file_timestamp(item.name)
                })
        return files    
    
    # save new timestamp of successful load
    def finish_load(self):
        if self.__new_last_load_timestamp == None:
            raise Exception("First call load_files()")

        nu.fs.put(
            self.__last_loaded_timestamp_file, 
            str(self.__new_last_load_timestamp),
            True
        )

    # return file with latest timestamp
    def __get_last_modified_file(self, files):
        max_modified_timestamp = None
        max_modified_timestamp_index = None
        max_modified_timestamp_file = None

        for file_index, file in enumerate(files):
            if (not max_modified_timestamp) or (file["timestamp"] > max_modified_timestamp):
                max_modified_timestamp = file["timestamp"]
                max_modified_timestamp_index = file_index
                max_modified_timestamp_file = file
            
        return (max_modified_timestamp_file, max_modified_timestamp_index)
        
    # create dateframe from file with metadata columns
    def __create_dataframe(self, file, file_format):
        df = None
        modify_timestamp = datetime.strptime(str(file["timestamp"]), "%Y%m%d%H%M%S")
        
        match file_format:
            case "json":
                df = pl.scan_json(file["path"])
            case "csv":
                df = pl.scan_csv(file["path"])
            case "parquet":
                df = pl.scan_parquet(file["path"])
            case _:
                raise Exception(f"Unsupported file format '{file_format}'")
        
        df = df.with_columns(
            lit(modify_timestamp).cast(pl.Datetime(time_unit="us",time_zone="UTC")).alias("L0_timestamp")
        )
        
        return df

    # get timestamp of last successful silver load
    def __get_last_load_timestamp(self):
        default_timestamp = 0

        if not nu.fs.exists(self.__last_loaded_timestamp_file):
            return default_timestamp
        
        last_load_timestamp_string = nu.fs.head(self.__last_loaded_timestamp_file)

        if not last_load_timestamp_string:
            return default_timestamp

        return int(last_load_timestamp_string)
    
    # get timestamp from file name
    def __get_file_timestamp(self, file_name):
        file_timestamp = int(file_name.split(".")[0])
        return file_timestamp