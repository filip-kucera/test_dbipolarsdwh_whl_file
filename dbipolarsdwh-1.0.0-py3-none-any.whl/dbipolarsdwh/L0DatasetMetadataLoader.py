import notebookutils as nu

class L0DatasetMetadataLoader:
    def __init__(self, lakehouse, dataset_name):
        self.__full_dataset_name = dataset_name
        self.__schema_name = dataset_name.split("/", 1)[0]
        self.__dataset_name = dataset_name.split("/", 1)[1]
        
        self.__last_increment_value_file = lakehouse.abfss_file_path(f"Files/Metadata/L0_checkpoints/{self.__dataset_name}.txt")

    # get filter value from last incremental load
    def get_last_increment_value(self):
        if not nu.fs.exists(self.__last_increment_value_file):
            return None
        return nu.fs.head(self.__last_increment_value_file)
    
    # update filter value for current incremental load
    def update_last_increment_value(self, value):
        nu.fs.put(
            self.__last_increment_value_file, 
            value,
            True
        )