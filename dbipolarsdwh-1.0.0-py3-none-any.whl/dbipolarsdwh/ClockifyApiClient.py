from requests import request

class ClockifyApiClient:
    def __init__(self, workspace_id, api_key):
        self.api_key = api_key
        self.api_base_url = f"https://api.clockify.me/api/v1/workspaces/{workspace_id}"
    
    def authorized_request(self, method, url, page = None, page_size = None, other_queries = None, body = None):
        headers = {"X-Api-Key": self.api_key}
        url = self.__compose_url(url, page = page, page_size = page_size, other_queries = other_queries)

        print(f"{method}: {url}")
        
        response = request(method, url, headers = headers, json = body)
        response = self.__handle_response(response)

        return response

    def authorized_get_paginated(self, url, page_size = 5000, other_queries = None):
        results = []
        next_page = 1

        while True:
            response = self.authorized_request("GET", url, page = next_page, page_size = page_size, other_queries = other_queries)
            body = response["body"]
            
            if not body:
                break
            
            results.extend(body)
            next_page += 1
        
        return results
    
    
    def __handle_response(self, response):
        status_code = response.status_code or response.status
        content_type = response.headers.get("Content-Type")

        if status_code >= 400:
            raise Exception(f"HTTP error with status code: {status_code}; content: '{response.text}'")
        
        response_body = None
        if "json" in content_type:
            response_body = response.json()
            response_body = response_body
        else:
            response_body = response.content

        return {
            "status_code": status_code,
            "body": response_body,
            "headers": response.headers
        }

    def __compose_url(self, url, page = None, page_size = None, other_queries = None):
        output = f"{self.api_base_url}/{url}?"

        if page:
            output = output + f"&page={page}"
        if page_size:
            output = output + f"&size={page_size}"

        if other_queries:
            query_keys = other_queries.keys()
            for k in query_keys:
                if other_queries[k] != None:
                    output = output + f"&{k}={other_queries[k]}"

        
        return output